@extends('layouts.app')
@extends('layouts.cobitBreadcrumbs')
@section('content')
<div class="container">
  <!-- Card Utama -->
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow border-0 rounded">
        <!-- Card Header -->
        <div class="card-header bg-primary text-white text-center py-3">
          <h4 class="mb-0">Design Factor 6</h4>
        </div>
        <!-- Card Body -->
        <div class="card-body p-4">
          <form action="{{ route('df6.store') }}" method="POST" onsubmit="return validateForm()">
            @csrf
            <input type="hidden" name="df_id" value="{{ $id }}">

            <!-- High Input -->
            <div class="assessment-item card mb-3">
              <div class="card-body">
                <div class="row align-items-center">
                  <div class="col-md-6">
                    <h6 class="mb-0 text-primary">High</h6>
                  </div>
                  <div class="col-md-6">
                    <input type="number" name="input1df6" id="input1df6" class="form-control" required>
                    <small class="text-muted">Masukkan nilai dalam persen (contoh: 33 untuk 33%).</small>
                  </div>
                </div>
              </div>
            </div>

            <!-- Normal Input -->
            <div class="assessment-item card mb-3">
              <div class="card-body">
                <div class="row align-items-center">
                  <div class="col-md-6">
                    <h6 class="mb-0 text-primary">Normal</h6>
                  </div>
                  <div class="col-md-6">
                    <input type="number" name="input2df6" id="input2df6" class="form-control" required>
                    <small class="text-muted">Masukkan nilai dalam persen (contoh: 33 untuk 33%).</small>
                  </div>
                </div>
              </div>
            </div>

            <!-- Low Input -->
            <div class="assessment-item card mb-3">
              <div class="card-body">
                <div class="row align-items-center">
                  <div class="col-md-6">
                    <h6 class="mb-0 text-primary">Low</h6>
                  </div>
                  <div class="col-md-6">
                    <input type="number" name="input3df6" id="input3df6" class="form-control" required>
                    <small class="text-muted">Masukkan nilai dalam persen (contoh: 34 untuk 34%).</small>
                  </div>
                </div>
              </div>
            </div>

            <!-- Error Message -->
            <div id="error-message" class="alert alert-danger mt-3" role="alert" style="display: none;">
              The sum of all fields must not exceed 100%.
            </div>

            <!-- Pie Chart -->
            <div class="chart-container mt-4" style="height: 300px;">
              <canvas id="pieChart"></canvas>
            </div>

            <!-- Radar Chart -->
            <div class="row mb-4 mt-4">
              <div class="col-md">
                <div class="card">
                  <div class="card-header text-center text-primary">
                    DF6 Radar Chart
                  </div>
                  <div class="card-body" style="height: 400px;">
                    <canvas id="radarChart"></canvas>
                  </div>
                </div>
              </div>
            </div>

            <!-- Layout: Relative Importance -->
            <div class="row mt-4">
              <!-- Relative Importance Radar Chart -->
              <div class="col-md-6 mb-3">
                <div class="card h-100">
                  <div class="card-header text-center text-primary">
                    Relative Importance (Radar Chart)
                  </div>
                  <div class="card-body">
                    <div class="w-100" style="height: 400px;">
                      <canvas id="relativeImportanceRadarChart"></canvas>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Relative Importance Table -->
              <div class="col-md-6 mb-3">
                <div class="card h-100">
                  <div class="card-header text-center text-primary">
                    Relative Importance Table
                  </div>
                  <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-sm" id="results-table">
                      <thead class="table-light">
                        <tr>
                          <th class="text-center text-primary">Index</th>
                          <th class="text-center text-primary">DF6 Score</th>
                          <th class="text-center text-primary">Relative Importance</th>
                        </tr>
                      </thead>
                      <tbody>
                        <!-- Data akan diisi oleh JavaScript -->
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <!-- Relative Importance Bar Chart -->
            <div class="row mt-4">
              <div class="col-12">
                <div class="card">
                  <div class="card-header text-center text-primary">
                    Relative Importance (Bar Chart)
                  </div>
                  <div class="card-body">
                    <div class="w-100" style="height: 700px;">
                      <canvas id="relativeImportanceChart"></canvas>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Submit Button -->
            <div class="text-center mt-4">
              <button type="submit" class="btn btn-primary btn-lg px-5">Submit Assessment</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  const ctx = document.getElementById('pieChart').getContext('2d');
  const pieChart = new Chart(ctx, {
      type: 'pie',
      data: {
          datasets: [{
              data: [33, 33, 33], // Default data
              backgroundColor: [
                  'rgba(255, 99, 132, 0.6)', // Red
                  'rgba(54, 162, 235, 0.6)',  // Blue
                  'rgba(255, 247, 0, 0.6)'    // Yellow
              ],
              borderColor: [
                  'rgba(255, 99, 132, 1)',
                  'rgba(54, 162, 235, 1)',
                  'rgba(255, 247, 0, 1)'
              ],
              borderWidth: 1
          }],
          labels: ['High', 'Normal', 'Low']
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
              legend: {
                  display: false // Hide legend
              }
          }
      }
  });

  function updatePieChart() {
      const input1 = parseFloat(document.getElementById('input1df6').value) || 0;
      const input2 = parseFloat(document.getElementById('input2df6').value) || 0;
      const input3 = parseFloat(document.getElementById('input3df6').value) || 0;

      // Update data for pie chart
      pieChart.data.datasets[0].data = [input1, input2, input3];

      // Update background colors dynamically
      pieChart.data.datasets[0].backgroundColor = [
          input1 > 0 ? 'rgba(255, 99, 132, 0.6)' : 'rgba(169, 169, 169, 0.6)',
          input2 > 0 ? 'rgba(54, 162, 235, 0.6)' : 'rgba(169, 169, 169, 0.6)',
          input3 > 0 ? 'rgba(255, 247, 0, 0.6)' : 'rgba(169, 169, 169, 0.6)'
      ];

      pieChart.update();
  }

  document.getElementById('input1df6').addEventListener('input', updatePieChart);
  document.getElementById('input2df6').addEventListener('input', updatePieChart);
  document.getElementById('input3df6').addEventListener('input', updatePieChart);

  function validateForm() {
      const input1 = parseFloat(document.getElementById('input1df6').value) || 0;
      const input2 = parseFloat(document.getElementById('input2df6').value) || 0;
      const input3 = parseFloat(document.getElementById('input3df6').value) || 0;
      const total = input1 + input2 + input3;

      if (total > 100) {
          document.getElementById('error-message').style.display = 'block';
          return false;
      }

      document.getElementById('error-message').style.display = 'none';
      return true;
  }
</script>
@endsection
