@extends('layouts.app')
@extends('layouts.cobitBreadcrumbs')
@section('content')
<div class="container">
  <!-- Card Utama -->
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow border-0 rounded">
        <!-- Card Header -->
        <div class="card-header bg-primary text-white text-center py-3">
          <h4 class="mb-0">Design Factor 5</h4>
        </div>
        <!-- Card Body -->
        <div class="card-body p-4">
          <form action="{{ route('df5.store') }}" method="POST" onsubmit="return validateForm()">
            @csrf
            <input type="hidden" name="df_id" value="{{ $id }}">

            <!-- High Input -->
            <div class="assessment-item card mb-3">
              <div class="card-body">
                <div class="row align-items-center">
                  <div class="col-md-6">
                    <h6 class="mb-0 text-primary">High</h6>
                  </div>
                  <div class="col-md-6">
                    <input type="number" name="input1df5" id="input1df5" class="form-control" required>
                    <small class="text-muted">Masukkan nilai dalam persen (contoh: 33 untuk 33%).</small>
                  </div>
                </div>
              </div>
            </div>

            <!-- Normal Input -->
            <div class="assessment-item card mb-3">
              <div class="card-body">
                <div class="row align-items-center">
                  <div class="col-md-6">
                    <h6 class="mb-0 text-primary">Normal</h6>
                  </div>
                  <div class="col-md-6">
                    <input type="number" name="input2df5" id="input2df5" class="form-control" required>
                    <small class="text-muted">Masukkan nilai dalam persen (contoh: 67 untuk 67%).</small>
                  </div>
                </div>
              </div>
            </div>

            <!-- Error Message -->
            <div id="error-message" class="alert alert-danger mt-3" role="alert" style="display: none;">
              The sum of High and Normal must be exactly 100%.
            </div>

            <!-- Pie Chart -->
            <div class="chart-container mt-4" style="height: 300px;">
              <canvas id="pieChart"></canvas>
            </div>

            <!-- Layout: Relative Importance -->
            <div class="row mt-4">
              <!-- Relative Importance Radar Chart -->
              <div class="col-md-6 mb-3">
                <div class="card h-100">
                  <div class="card-header text-center text-primary">
                    Relative Importance (Radar Chart)
                  </div>
                  <div class="card-body">
                    <div class="w-100" style="height: 400px;">
                      <canvas id="relativeImportanceRadarChart"></canvas>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Relative Importance Table -->
              <div class="col-md-6 mb-3">
                <div class="card h-100">
                  <div class="card-header text-center text-primary">
                    Relative Importance Table
                  </div>
                  <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-sm" id="results-table">
                      <thead class="table-light">
                        <tr>
                          <th class="text-center text-primary">Index</th>
                          <th class="text-center text-primary">DF5 Score</th>
                          <th class="text-center text-primary">Relative Importance</th>
                        </tr>
                      </thead>
                      <tbody>
                        <!-- Data akan diisi oleh JavaScript -->
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            <!-- Relative Importance Bar Chart -->
            <div class="row mt-4">
              <div class="col-12">
                <div class="card">
                  <div class="card-header text-center text-primary">
                    Relative Importance (Bar Chart)
                  </div>
                  <div class="card-body">
                    <div class="w-100" style="height: 700px;">
                      <canvas id="relativeImportanceChart"></canvas>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Submit Button -->
            <div class="text-center mt-4">
              <button type="submit" class="btn btn-primary btn-lg px-5">Submit Assessment</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  let isUpdating = false;

  const ctx = document.getElementById('pieChart').getContext('2d');
  const pieChart = new Chart(ctx, {
      type: 'pie',
      data: {
          datasets: [{
              data: [50, 50], // Default data
              backgroundColor: [
                  'rgba(255, 99, 132, 0.6)', // Red for High
                  'rgba(54, 162, 235, 0.6)'  // Blue for Normal
              ],
              borderColor: [
                  'rgba(255, 99, 132, 1)', // Red border
                  'rgba(54, 162, 235, 1)'  // Blue border
              ],
              borderWidth: 1
          }],
          labels: ['High', 'Normal']
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
              legend: {
                  display: false // Hide legend
              }
          }
      }
  });

  function updatePieChart() {
      const input1 = parseFloat(document.getElementById('input1df5').value) || 0;
      const input2 = parseFloat(document.getElementById('input2df5').value) || 0;

      // Update data for pie chart
      pieChart.data.datasets[0].data = [input1, input2];
      // Update chart
      pieChart.update();
  }

  // Event listener untuk field High
  document.getElementById('input1df5').addEventListener('input', function() {
      if (!isUpdating) {
          isUpdating = true;
          let input1 = parseFloat(this.value) || 0;
          // Set field Normal secara otomatis
          document.getElementById('input2df5').value = 100 - input1;
          updatePieChart();
          isUpdating = false;
      }
  });

  // Event listener untuk field Normal
  document.getElementById('input2df5').addEventListener('input', function() {
      if (!isUpdating) {
          isUpdating = true;
          let input2 = parseFloat(this.value) || 0;
          // Set field High secara otomatis
          document.getElementById('input1df5').value = 100 - input2;
          updatePieChart();
          isUpdating = false;
      }
  });

  function validateForm() {
      const input1 = parseFloat(document.getElementById('input1df5').value) || 0;
      const input2 = parseFloat(document.getElementById('input2df5').value) || 0;
      const total = input1 + input2;

      // Check if the total is exactly 100
      if (total !== 100) {
          document.getElementById('error-message').style.display = 'block';
          return false;
      }

      document.getElementById('error-message').style.display = 'none';
      return true;
  }
</script>


@endsection