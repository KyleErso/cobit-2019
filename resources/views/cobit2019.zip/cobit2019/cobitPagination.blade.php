@auth
@php
    // Tentukan DF yang sedang aktif berdasarkan route name
    $currentDF = 1;
    for ($i = 1; $i <= 10; $i++) {
        if (Route::currentRouteName() == 'df' . $i . '.form') {
            $currentDF = $i;
            break;
        }
    }
@endphp
<div class="container-fluid d-flex justify-content-center">
    <nav aria-label="Page navigation">
        <ul class="pagination pagination-sm">
            {{-- Tombol Previous --}}
            <li class="page-item {{ $currentDF == 1 ? 'disabled' : '' }}">
                <a class="page-link" 
                   href="{{ $currentDF == 1 ? '#' : route('df' . ($currentDF - 1) . '.form', ['id' => $currentDF - 1]) }}"
                   aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            {{-- Loop DF1 sampai DF10 --}}
            @for ($i = 1; $i <= 10; $i++)
                @if ($currentDF == $i)
                    <li class="page-item active" aria-current="page">
                        <span class="page-link">DF {{ $i }}</span>
                    </li>
                @else
                    <li class="page-item">
                        <a class="page-link" href="{{ route('df' . $i . '.form', ['id' => $i]) }}">
                            DF {{ $i }}
                        </a>
                    </li>
                @endif
            @endfor
            {{-- Tombol Next --}}
            <li class="page-item {{ $currentDF == 10 ? 'disabled' : '' }}">
                <a class="page-link" 
                   href="{{ $currentDF == 10 ? '#' : route('df' . ($currentDF + 1) . '.form', ['id' => $currentDF + 1]) }}"
                   aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>
</div>
@endauth

